## this is fibonacci's game
import random
import pygame as pg
import lib
#############################################################################
#                                                                           #
#               fibonacci.num is the number of stone.                       #
#                                                                           #
############################################################################# 
class fibonacci:
    def __init__(self,num):
        self.num=num
        self.fib=[1,2]                          # init fibonacci sequence
        self.check=[]                       
        self.winner='ai'                        # init winner
        self.ai_take=0                          # the number of ai taken
        self.state=3                            # used to switch the screen of home and different games
        self.total=num                          # used to show the highlight
        self.mmax=num-1                         # used to show the range of taking
        self.take=0                             
        self.flag=0                             # flag is used to show if player win
        for i in range(1,20):                   # generate fibonacci sequence
            self.fib=self.fib+[self.fib[i]+self.fib[i-1]]
        
        pg.init()
        self.screen = pg.display.set_mode((1280,800))
        self.screen.fill(pg.Color(255,255,255))
        pg.display.set_caption("fibonacci-game!")    # title
        pg.display.flip()

    def divide(self):                           # divide the number into many fibonacci number
        self.check=[]
        tmp=self.num                            # keep the vaule of self.num
        for i in range(1,21):
            if self.fib[20-i]==tmp:
                self.check=self.check+[self.fib[20-i]]
                break
            if self.fib[20-i]<tmp:
                tmp=tmp-self.fib[20-i]
                self.check=self.check+[self.fib[20-i]]

    def win(self):                              # check if AI will always win
        return self.check[len(self.check)-1]<self.mmax

    def ans(self):                              # calculate the number of AI taking
        return self.check[len(self.check)-1]

    def run(self):                              # AI take stones and check the winner

        if self.num==0:
            self.winner='player'
            return 
        self.divide()
        if self.win():                          # AI will always win, do the best way to keep winning
            self.ai_take=self.ans()
        else:                                   # AI may lose game, taking random
            self.ai_take=random.randint(1,self.mmax)
        self.num=self.num-self.ai_take
        self.mmax=2*self.ai_take
###############################################################################
    def loop(self):                              # main loop of this game
        while self.state==3 and self.num>0:
            e=pg.event.poll()
            if e.type==pg.QUIT:
                pg.quit()
                return 
            if e.type == pg.MOUSEBUTTONUP:
                x, y = e.pos
                if pg.Rect(0, 0, 100, 100).collidepoint(x, y):  # Eas
                    self.state=0
                    return  
                tmp=self.total-self.num
                take=0
                for j in range(0,5):
                    for i in range(0,6):
                        if tmp>0:
                            tmp-=1
                        else:                   # check the click
                            take+=1
                            if pg.Rect(350+100*i, 325+80*j, 45, 45).collidepoint(x, y):
                                if(take<=self.mmax):
                                    self.num-=take
                                    self.mmax=2*take
                                    self.take=take
                                    if self.num==0:
                                        self.winner='player'
                                    self.run()
                        
################################################################################################
            self.screen.fill('white')
            mx=pg.mouse.get_pos()[0]      
            my=pg.mouse.get_pos()[1]
            tmp=self.total-self.num
            choose=0
            check=0                                 # check if mouse on one of stones
            for j in range(0,30):
                check=mx>350+100*(j%6) and mx<395+100*(j%6) and my>325+80*(j//6) and my<370+80*(j//6)
                if check:
                    choose=j
                    break
            for j in range(0,5):
                for i in range(0,6):               # highlight or black or normal
                    if tmp>0:
                        tmp-=1
                        pg.draw.rect(self.screen,pg.Color(0,0,0),pg.Rect(350+100*i, 325+80*j, 45, 45))
                    elif check:
                        if 6*j+i<=choose:
                            pg.draw.rect(self.screen,pg.Color(248,199,231),pg.Rect(350+100*i, 325+80*j, 45, 45))
                        else:
                            pg.draw.rect(self.screen,pg.Color(148,99,131),pg.Rect(350+100*i, 325+80*j, 45, 45))
                    else:
                        pg.draw.rect(self.screen,pg.Color(148,99,131),pg.Rect(350+100*i, 325+80*j, 45, 45))
                        
            
            
            fontobj=pg.font.Font('font/SourceHanSansHWSC-Regular.otf', 50)
            text=fontobj.render("Eas", True, (0,255,0),(0,0,0))
            text1=text.get_rect()
            text1.center=(50,50)
            self.screen.blit(text, text1)                   #printf("Eas") with a backgroud
            
            lib.printf("Bash told me you are very clever, If you win this game, this helmet will be yours!",29,650,110,(200,30,20),self.screen)
            lib.printf("There are 30 stones, we will take them in turn.                                   ",29,650,160,(200,30,20),self.screen)
            lib.printf("who take the last one will win this game.                                         ",29,650,190,(200,30,20),self.screen)
            lib.printf("we can take any number from 1 to 29 of them in the first step.                    ",29,650,220,(200,30,20),self.screen)
            lib.printf("next, we can choose any number from 1 to 2 times of the number of the last taking.",29,650,250,(200,30,20),self.screen)
            lib.printf(f"in this step, you can take from 1 to {self.mmax}!",29,650,290,(200,30,20),self.screen)
            lib.printf(f"{self.num} remained!                             ",29,650,730,(200,30,20),self.screen)
                                                            # print rules
            lib.printf(f"I take {self.take}",30,100,700,(0,0,0),self.screen)
            lib.printf(f"I take {self.ai_take}",30,1000,700,(0,0,0),self.screen)
            
            pg.display.flip()
        self.flag=lib.output(self.winner,self.screen)
        self.state=0
        return 

# fibonacci(30).loop()
# pg.quit()
#fib_num = 40   # initial number of stone
#print(fibonacci(fib_num).result())

