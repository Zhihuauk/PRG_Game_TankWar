## this is nimm's game

import random
import pygame as pg
import lib
    
class nimm:
    def __init__(self,lst):
        self.lst=lst
        self.winner='ai'                        # init winner
        self.state=4                            # used to switch the screen of home and different games
        self.take=0                             # which group is chosen
        self.flag=0                             # flag is used to show if player win
        self.player_take=0                      # the number of player taken
        pg.init()
        self.screen = pg.display.set_mode((1280,800))
        self.screen.fill(pg.Color(255,255,255))
        pg.display.set_caption("nimm-game!")    # title
        pg.display.flip()

    def win(self):                          # check if AI will always win
        return self.lst[0]^self.lst[1]^self.lst[2]
    
    def run(self):                              # AI take stones and check the winner
        if self.lst[0]+self.lst[1]+self.lst[2]==0:
            self.winner = 'player'
            return
        if self.win():                          # AI will always win, do the best way to keep winning
            if self.lst[0]^self.lst[1]<self.lst[2]:
                self.lst[2]=self.lst[0]^self.lst[1]
            elif self.lst[1]^self.lst[2]<self.lst[0]:
                self.lst[0]=self.lst[1]^self.lst[2]
            elif self.lst[0]^self.lst[2]<self.lst[1]:
                self.lst[1]=self.lst[0]^self.lst[2]
        else:                                   # AI may lose game, taking random
            t=random.randint(0,2)
            while self.lst[t]==0:
                t=random.randint(0,2)
            self.lst[t]-=random.randint(1,self.lst[t])
###############################################################################################
    def loop(self):                              # main loop of this game
        while self.state==4 and self.lst[0]+self.lst[1]+self.lst[2]>0:
            e=pg.event.poll()
            if e.type==pg.QUIT:
                pg.quit()
                return 
            if e.type == pg.MOUSEBUTTONUP:
                x, y = e.pos
                if pg.Rect(0, 0, 100, 100).collidepoint(x, y):  # Eas
                    self.state=0
                    return  
                if pg.Rect(520, 680, 170, 45).collidepoint(x, y):   # group 1
                    self.take='group 1'
                    if self.player_take>0 and self.player_take<=self.lst[0]:
                        self.lst[0]-=self.player_take
                        self.run()
                    
                if pg.Rect(520+220, 680, 170, 45).collidepoint(x, y):   # group 2
                    self.take='group 2'
                    if self.player_take>0 and self.player_take<=self.lst[1]:
                        self.lst[1]-=self.player_take
                        self.run()
                    
                if pg.Rect(520+220*2, 680, 170, 45).collidepoint(x, y):   # group 3
                    self.take='group 3'
                    if self.player_take>0 and self.player_take<=self.lst[2]:
                        self.lst[2]-=self.player_take
                        self.run()
                
                if pg.Rect(730, 480, 45, 45).collidepoint(x, y) and self.player_take<99: #+
                    self.player_take+=1
                if pg.Rect(790, 480, 45, 45).collidepoint(x, y) and self.player_take>0:  #-
                    self.player_take-=1

            self.screen.fill('white')
            
            lib.printf(f"group 1: {self.lst[0]}   group 2: {self.lst[1]}   group 3: {self.lst[2]}",40,640,400,(100,1,100),self.screen)
            lib.printf(f"you take from {self.take}",30,800,750,(100,1,100),self.screen)
            lib.pg.draw.rect(self.screen,pg.Color(190,19,100),pg.Rect(790, 480, 45, 45))
            pg.draw.rect(self.screen,pg.Color(100,199,190),pg.Rect(730, 480, 45, 45))
            for i in range(0,3):
                pg.draw.rect(self.screen,pg.Color(100*i,199,100*(2-i)),pg.Rect(520+220*i, 680, 170, 45))
                                                            # show the button
            lib.printf("you will take from   group 1    group 2    group 3",40,600,700,(0,0,0),self.screen)
            lib.printf(f"you will take {self.player_take}   +  -",40,600,500,(100,1,100),self.screen)

            fontobj=pg.font.Font('font/SourceHanSansHWSC-Regular.otf', 50)
            text=fontobj.render("Eas", True, (0,255,0),(0,0,0))
            text1=text.get_rect()
            text1.center=(50,50)
            self.screen.blit(text, text1)                   #printf("Eas") with a backgroud
            
            lib.printf("WOW!",40,650,80,(200,30,20),self.screen)
            lib.printf("you are standing in here! It seems like you are so clever to pass previous tests   ",29,650,130,(200,30,20),self.screen)
            lib.printf("so here is a great challenge for you. as you know, winner will take the last stone.",29,650,160,(200,30,20),self.screen)
            lib.printf("if you win this game, you can resurgence again!                                    ",29,650,190,(200,30,20),self.screen)
            lib.printf("there are 3 groups of stones, we will take them in turn.                           ",29,650,220,(200,30,20),self.screen)
            lib.printf("we can take any number stones from any one group in each step.                     ",29,650,250,(200,30,20),self.screen)
            lib.printf("good luck!",29,650,280,(200,30,20),self.screen)
                                                            # print rules
            
            pg.display.flip()
        self.flag=lib.output(self.winner,self.screen)
        self.state=0
        return 
