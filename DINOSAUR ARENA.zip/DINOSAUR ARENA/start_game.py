# -*- coding: utf-8 -*-
"""
Created on Sun Dec 12 06:53:33 2021

@author: liuxx
"""
import mapp
import pygame as pg
import boyi
import tank
import interface

def delay(t,Screen):                                # game will delay for 3 seconds
    cnt=t
    while cnt>=0:
        pg.draw.rect(screen, pg.Color(0,0,0), pg.Rect(550,250,100,100))
        boyi.lib.printf(f"{cnt}",100,600,300,(255,255,255),Screen)
        pg.display.flip()
        pg.time.wait(1000)
        cnt-=1
        
pg.init()
#游戏舞台
screen=pg.display.set_mode((mapp.DATA.SCREEN_WIDTH,mapp.DATA.SCREEN_HEIGHT))   

pg.display.set_caption(mapp.DATA.GAME_TITLE)

clock=pg.time.Clock()
# clock.tick(mapp.DATA.fps)


pg.display.flip()
flag_delay=0                                        # to check if there need a delay for 3 seconds
while True:        
    pg.mixer.music.load(r'./voice/jtlr.mp3')        # set a backgroud music in start interface
    pg.mixer.music.play()
    if interface.start_interface(screen)==1:        # start game
        gameround=0                                 # init game information
        mapp.update_map(gameround)
        a=tank.tank(0,[mapp.map_data.me[0][0], mapp.map_data.me[0][1]], mapp.map_data.me[0][2],screen,mapp.DATA.MAP_1)
        enemy=[]
        for i in mapp.map_data.enemy[gameround]:    # get informationof enemies
            enemy=enemy+[tank.tank(1,[i[0], i[1]], i[2],screen,mapp.DATA.MAP_1)]
        boyi_flag=[-1,-1,-1,-1]                     # init flag
        flag_delay=1                                # at the start of game, there need be a delay
        frame_cnt=0                                 # a counter, used to calculate the frame of picture
        pg.mixer.music.stop()                       # game start, music stop
        while True:
            clock.tick(mapp.DATA.fps)               # keep the frequence of frame
            frame_cnt+=1
            if frame_cnt>=100000:                   # counter 
                frame_cnt=0
            e=pg.event.poll()
            if e.type==pg.QUIT:
                pg.quit()
                break
            if a.hp<=0:                             # you are died
                interface.loop_lose(a,boyi_flag,screen)
                flag_delay=1
                if a.hp<=0:
                    break
            screen.fill(pg.Color("blue"))
            BG=pg.image.load("./img/other/BG.png")  # load the back ground
            tranBG=pg.transform.scale(BG, (1200,600))
            #把缩放后的BG图片放到左上角(0,0)上去
            screen.blit(tranBG,(0,0))
            mapp.DATA.draw_map(screen)
            a.run(enemy,e,(frame_cnt//5)%4)         # run codes in tank.py
            if len(enemy)==0:                       # all of enemies are died, you win
                if interface.loop_win(gameround,screen)==0: 
                    break
                gameround+=1                        # go to next ground
                mapp.update_map(gameround)          # update the map
                enemy=[]                            # init enemy
                for i in mapp.map_data.enemy[gameround]:    # update enemies and player
                    enemy=enemy+[tank.tank(1,[i[0], i[1]], i[2],screen,mapp.DATA.MAP_1)]
                a=tank.tank(0,[mapp.map_data.me[gameround][0], mapp.map_data.me[gameround][1]], mapp.map_data.me[gameround][2],screen,mapp.DATA.MAP_1)
            for i in enemy:                         # enemies moving 
                i.self_driving([a])
                if i.hp<=0:                         # enemy is died, remove it
                    enemy.remove(i)
            
            if flag_delay==1:                       # check the flag and delay
                delay(3,screen)
                flag_delay=0
            pg.display.flip()
    
pg.quit() 

