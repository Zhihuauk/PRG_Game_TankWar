## this is bash's game

import random
import pygame as pg
import lib
#############################################################################
#                                                                           #
#   bash.mmax is the range of taking, in each step player can take 1-maxx   #
#                                                                           #
#   bash.num is the number of stone.                                        #
#                                                                           #
#   bash.state is used to switch the screen of home and different games     #
#                                                                           #
############################################################################# 
class bash:
    def __init__(self,mmax,num,state):
        self.state=state
        self.mmax=mmax
        self.num=num
        self.total=num                          # used to show the highlight
        pg.init()
        self.screen = pg.display.set_mode((1280,800))
        self.screen.fill(pg.Color(255,255,255))
        pg.display.set_caption("bash-game!")    # title
        pg.display.flip()
        self.winner='ai'                        # init winner                                
        self.flag=0                             # flag is used to show if player win
        
    def ans(self):                              # check if AI will always win and calculate the number of AI taking
        return self.num%(self.mmax+1)
    
    def run(self):                              # AI take stones and check the winner
        if self.num==0:
            self.winner='player'
            return
        if self.ans():                          # AI will always win, do the best way to keep winning
            self.ai_take=self.ans()
        else:                                   # AI may lose game, taking random
            self.ai_take=random.randint(1,2)
        self.num=self.num-self.ai_take


###############################################################################################
    def loop(self):                             # main loop of this game
        while self.state==1 and self.num>0:
            e=pg.event.poll()
            if e.type==pg.QUIT:
                pg.quit()
                return
            if e.type == pg.MOUSEBUTTONUP:
                x, y = e.pos
                if pg.Rect(0, 0, 100, 100).collidepoint(x, y):  # Eas
                    self.state=0
                    return  
                tmp=self.total-self.num
                take=0
                for j in range(0,4):
                    for i in range(0,5):
                        if tmp>0:
                            tmp-=1
                        else:                   # check the click
                            take+=1             
                            if pg.Rect(420+100*i, 325+100*j, 45, 45).collidepoint(x, y):
                                if(take<=self.mmax):
                                    self.num-=take
                                    if self.num==0:
                                        self.winner='player'
                                    self.run()
                        
################################################################################################
            self.screen.fill('white')
            mx=pg.mouse.get_pos()[0]      
            my=pg.mouse.get_pos()[1]
            tmp=self.total-self.num
            choose=0
            check=0                                 # check if mouse on one of stones
            for j in range(0,20):
                check=mx>420+100*(j%5) and mx<465+100*(j%5) and my>325+100*(j//5) and my<370+100*(j//5)
                if check:
                    choose=j
                    break
            for j in range(0,4):                    # highlight or black or normal
                for i in range(0,5):   
                    if tmp>0:
                        tmp-=1
                        pg.draw.rect(self.screen,pg.Color(0,0,0),pg.Rect(420+100*i, 325+100*j, 45, 45))
                    elif check:
                        if 5*j+i<=choose:
                            pg.draw.rect(self.screen,pg.Color(248,199,231),pg.Rect(420+100*i, 325+100*j, 45, 45))
                        else:
                            pg.draw.rect(self.screen,pg.Color(148,99,131),pg.Rect(420+100*i, 325+100*j, 45, 45))
                    else:
                        pg.draw.rect(self.screen,pg.Color(148,99,131),pg.Rect(420+100*i, 325+100*j, 45, 45))
            
            fontobj=pg.font.Font('font/SourceHanSansHWSC-Regular.otf', 50)
            text=fontobj.render("Eas", True, (0,255,0),(0,0,0))
            text1=text.get_rect()
            text1.center=(50,50)
            self.screen.blit(text, text1)                   #printf("Eas") with a backgroud
            
            lib.printf("There is a chance to resurgence if you can win this game!",29,650,110,(200,30,20),self.screen)
            lib.printf("There are 20 stones, we take 1 or 2 stones in turn.      ",29,650,210,(200,30,20),self.screen)
            lib.printf("who take the last one will win this game.                ",29,650,240,(200,30,20),self.screen)
            lib.printf("you first!",29,650,270,(200,30,20),self.screen)
            lib.printf(f"{self.num} remained!",29,650,730,(200,30,20),self.screen)
                                                            # print rules
            
            pg.display.flip()
        self.flag=lib.output(self.winner,self.screen)
        self.state=0
        return 
    

