# -*- coding: utf-8 -*-
"""
Created on Fri Dec  3 06:00:42 2021

@author: liuxx
"""
import pygame as pg
import bash
import fibonacci as fib
import Wythoff as wyf
import nimm
import lib

#############################################################################
#                                                                           #
#                   the homepage of game theory section                     #
#                                                                           #
############################################################################# 

def boyi(screen,tan,flag):
    screen=pg.display.set_mode((1280,800))
    state=0             # switch the games and home
    
    while True:
        e=pg.event.poll()
        if e.type==pg.QUIT:
            pg.quit()
            return -1
        elif e.type == pg.MOUSEBUTTONUP:
            if state==0: #1
                x, y = e.pos
                for i in range(0,4):            # check click
                    if pg.Rect(300+200*i, 425, 60, 60).collidepoint(x, y):
                        state=i+1
            x, y = e.pos
            if pg.Rect(0, 0, 100, 100).collidepoint(x, y):
                return False    
    
    ############################################################################
        if state==0:                            # home
            screen.fill('white')   
            lib.printf("Choose your game!",80,650,150,(0,255,0),screen)
            lib.printf("you can choose any one game to resurrect your dinosaur",40,650,250,(0,255,0),screen)
            lib.printf("each game can resurrect your dinosaur only once       ",40,650,290,(0,255,0),screen)
                                                           # print rules
            fontobj=pg.font.Font('font/SourceHanSansHWSC-Regular.otf', 50)
            text=fontobj.render("Eas", True, (0,255,0),(0,0,0))
            text1=text.get_rect()
            text1.center=(50,50)
            screen.blit(text, text1)            # Eas
    ############################################################################
            pg.draw.rect(screen,pg.Color(248,199,110),pg.Rect(300, 425, 60, 60))
            pg.draw.rect(screen,pg.Color(248,11,204),pg.Rect(500, 425, 60, 60))
            pg.draw.rect(screen,pg.Color(28,11,204),pg.Rect(700, 425, 60, 60))
            pg.draw.rect(screen,pg.Color(248,11,4),pg.Rect(900, 425, 60, 60))
            for i in range(0,4):
                lib.printf(f"{i+1}",40,330+200*i,455,(0,200,0),screen)
                                                # show button
            for i in range(0,4):
                if flag[i]==0:
                    lib.printf("tried",50,330+200*i,490,(255,0,0),screen)
                if flag[i]==1:
                    lib.printf("pass",50,320+200*i,490,(0,255,0),screen)
    ############################################################################
        if state==1:                            # game 1
            a=bash.bash(2,20,1)
            a.loop()
            
            state=a.state
            if flag[0]<a.flag:
                flag[0]=a.flag
                if a.flag==1:
                    tan.hp=30
                    return 11
    ###########################################################################
        if state==2:                            # game 2
            a=wyf.wythoff([10,7])
            a.loop()
            state=a.state
            if flag[1]<a.flag:
                flag[1]=a.flag
                if a.flag==1:
                    tan.hp=30
                    return 21
    #############################################################################
        if state==3:                            # game 3
            a=fib.fibonacci(30)
            a.loop()
            state=a.state
            if flag[2]<a.flag:
                flag[2]=a.flag
                if a.flag==1:
                    tan.hp=30
                    return 31
        pg.display.flip()
    ############################################################################
        if state==4:                            # game 4
            a=nimm.nimm([14,21,21])
            a.loop()
            state=a.state
            if flag[3]<a.flag:
                flag[3]=a.flag
                if a.flag==1:
                    tan.hp=30
                    return 41
        pg.display.flip()
    # the vaule of return is the game_number*10+1 to show this game has been passed

