## Wythoff's game

import random
import pygame as pg

import lib
#############################################################################
#                                                                           #
#   wythoff.lst is a list with 2 elements, the number of 2 groups of stones #
#                                                                           #
############################################################################# 
class wythoff:
    def __init__(self,lst):
        self.lst=lst
        self.winner='ai'                        # init winner
        self.gold=1.618033988749895             # Golden ratio, it is used to check if AI will always win 
        self.state=2                            # used to switch the screen of home and different games
        self.take=0                             # which group is chosen
        self.flag=0                             # flag is used to show if player win
        pg.init()
        self.screen = pg.display.set_mode((1280,800))
        self.screen.fill(pg.Color(255,255,255))
        pg.display.set_caption("wythoff-game!")    # title
        pg.display.flip()
        self.player_take=0                      # the number of player taken
        
    def win(self,a,b):                          # check if AI will always win
        x=min(a,b)
        d=max(a,b)-x
        return not int(d*self.gold)==x

    def run(self):                              # AI take stones and check the winner
        if self.lst[0]==self.lst[1] or self.lst[0]*self.lst[1]==0:
            self.lst[0]=0
            self.lst[1]=0
            return 
            
        if self.lst[0]+self.lst[1]==0:
            self.winner='player'
            return 
                        
        if self.lst[0]>self.lst[1]:             # find the big one and small one
            big=0
            sml=1
        else:
            big=1
            sml=0
        f=0
        if self.win(self.lst[0],self.lst[1]):   # AI will always win, do the best way to keep winning
            diff=self.lst[big]-self.lst[sml]
            if int(diff*self.gold)<self.lst[sml]:
                self.lst[sml]=int(diff*self.gold)
                self.lst[big]=int(self.lst[sml]+diff)
            else:
                for i in range(1,self.lst[sml]):
                    if not self.win(i,self.lst[big]):
                        self.lst[sml]=i
                        f=1
                if f==0:
                    for i in range(1,self.lst[big]):
                        if not self.win(i,self.lst[sml]):
                            self.lst[big]=i
        else:                                   # AI may lose game, taking random
            self.lst[big]=random.randint(0,self.lst[big]-1)
            
###############################################################################################
    def loop(self):                             # main loop of this game
        while self.state==2 and self.lst[0]+self.lst[1]>0:
            e=pg.event.poll()
            if e.type==pg.QUIT:
                pg.quit()
                return 
            if e.type == pg.MOUSEBUTTONUP:
                x, y = e.pos
                if pg.Rect(0, 0, 100, 100).collidepoint(x, y):  # Eas
                    self.state=0
                    return
                if pg.Rect(520, 680, 170, 45).collidepoint(x, y):   # group 1
                    self.take='group 1'
                    if self.player_take>0 and self.player_take<=self.lst[0]:
                        self.lst[0]-=self.player_take
                        if self.lst[0]*self.lst[1]==0:
                            self.winner='player'
                            self.flag=lib.output(self.winner,self.screen)
                            self.state=0
                            return
                        self.run()
                    
                if pg.Rect(520+220, 680, 170, 45).collidepoint(x, y):   # group 2
                    self.take='group 2'
                    if self.player_take>0 and self.player_take<=self.lst[1]:
                        self.lst[1]-=self.player_take
                        if self.lst[0]*self.lst[1]==0:
                            self.winner='player'
                            self.flag=lib.output(self.winner,self.screen)
                            self.state=0
                            return
                        self.run()
                    
                if pg.Rect(520+220*2, 680, 170, 45).collidepoint(x, y):   # both
                    self.take='both'
                    if self.player_take>0 and self.player_take<=self.lst[0] and self.player_take<=self.lst[1]:
                        self.lst[0]-=self.player_take
                        self.lst[1]-=self.player_take
                        if self.lst[0]*self.lst[1]==0:
                            self.winner='player'
                            self.flag=lib.output(self.winner,self.screen)
                            self.state=0
                            return
                        self.run()
                
                if pg.Rect(730, 480, 45, 45).collidepoint(x, y) and self.player_take<11: #+
                    self.player_take+=1
                if pg.Rect(790, 480, 45, 45).collidepoint(x, y) and self.player_take>0:  #-
                    self.player_take-=1
                    
            self.screen.fill('white')
                
            lib.printf("I know you want resurgence. Win this game please!                            ",30,650,110,(200,30,20),self.screen)
            lib.printf("There are two groups of stones, we will take them in turn.                   ",30,650,160,(200,30,20),self.screen)
            lib.printf("The person who take the last stone will win this game.                       ",30,650,190,(200,30,20),self.screen)
            lib.printf("In each step we can take any number of stones from one group.                ",30,650,220,(200,30,20),self.screen)
            lib.printf("Or we can take the same number from both group.                              ",30,650,250,(200,30,20),self.screen)
            lib.printf("you need to edit the number first, and then press the button to choose group.",30,650,280,(200,30,20),self.screen)
                                                            # print rules
            lib.printf(f"group 1: {self.lst[0]}",60,300,400,(100,1,100),self.screen)
            lib.printf(f"group 2: {self.lst[1]}",60,900,400,(100,1,100),self.screen)
            lib.printf(f"you take from {self.take}",30,800,750,(100,1,100),self.screen)
            pg.draw.rect(self.screen,pg.Color(190,19,100),pg.Rect(790, 480, 45, 45))
            pg.draw.rect(self.screen,pg.Color(100,199,190),pg.Rect(730, 480, 45, 45))
            for i in range(0,3):
                pg.draw.rect(self.screen,pg.Color(100*i,199,100*(2-i)),pg.Rect(520+220*i, 680, 170, 45))
                                                            # show the button
            lib.printf("you will take from   group 1    group 2      both",40,600,700,(0,0,0),self.screen)
            lib.printf(f"you will take {self.player_take}   +  -",40,600,500,(100,1,100),self.screen)

            fontobj=pg.font.Font('font/SourceHanSansHWSC-Regular.otf', 50)
            text=fontobj.render("Eas", True, (0,255,0),(0,0,0))
            text1=text.get_rect()
            text1.center=(50,50)
            self.screen.blit(text, text1)                   #printf("Eas") with a backgroud
            
            pg.display.flip()
            
        self.flag=lib.output(self.winner,self.screen)
        self.state=0
                
# wythoff([10,7]).loop()
# pg.quit()
